// Package TY
package Ty;

public class Ty {
    public int theory;
    public int practicals;

    public Ty(int theory, int practicals) {
        this.theory = theory;
        this.practicals = practicals;
    }
}
