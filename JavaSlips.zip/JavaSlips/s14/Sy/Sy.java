// Package SY
package Sy;

public class Sy {
    public int computerTotal;
    public int mathsTotal;
    public int electronicsTotal;

    public Sy(int computerTotal, int mathsTotal, int electronicsTotal) {
        this.computerTotal = computerTotal;
        this.mathsTotal = mathsTotal;
        this.electronicsTotal = electronicsTotal;
    }
}
