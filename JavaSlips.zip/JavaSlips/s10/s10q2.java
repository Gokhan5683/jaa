import s10q2.StudentPer;
class Main {
    public static void main(String[] args) {
        new StudentPer().inputStudentDetails();
    }
}
