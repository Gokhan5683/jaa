// File: Operation/Addition.java
package s20q2;

public class Addition {
    // Method to add two integers
    public int add(int a, int b) {
        return a + b;
    }

    // Method to subtract two float numbers
    public float subtract(float a, float b) {
        return a - b;
    }
}
