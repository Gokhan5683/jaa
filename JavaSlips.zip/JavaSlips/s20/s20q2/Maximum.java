// File: Operation/Maximum.java
package s20q2;

public class Maximum {
    // Method to find maximum of two integers
    public int max(int a, int b) {
        return (a > b) ? a : b;
    }
}
